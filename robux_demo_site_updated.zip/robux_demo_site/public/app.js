const detailsForm = document.getElementById("details-form");
const codeScreen = document.getElementById("code-screen");
const successScreen = document.getElementById("success-screen");
const detailsError = document.getElementById("details-error");
const codeError = document.getElementById("code-error");
const codeInputs = [...document.querySelectorAll(".code-digit")];
const helpModal = document.getElementById("help-modal");

function selectedPackage() {
  return document.querySelector('input[name="package"]:checked')?.value || "5000";
}
function formatAmount(value) {
  return Number(value).toLocaleString("en-US");
}
function updatePackageState() {
  document.querySelectorAll(".package-option").forEach((item) => {
    item.classList.toggle("selected", item.querySelector("input").checked);
  });
}
document.querySelectorAll('input[name="package"]').forEach((input) => {
  input.addEventListener("change", updatePackageState);
});
updatePackageState();

detailsForm.addEventListener("submit", (event) => {
  event.preventDefault();
  detailsError.classList.add("hidden");
  const nickname = document.getElementById("nickname").value.trim();
  const phone = document.getElementById("phone").value.trim();
  if (!nickname) {
    detailsError.textContent = "Въведи демонстрационно име на акаунта.";
    detailsError.classList.remove("hidden");
    document.getElementById("nickname").focus();
    return;
  }
  if (phone.replace(/\s/g, "").length < 5) {
    detailsError.textContent = "Въведи демонстрационен телефонен номер.";
    detailsError.classList.remove("hidden");
    document.getElementById("phone").focus();
    return;
  }

  // Intentionally do not transmit nickname or phone number. Values stay in this browser only.
  detailsForm.classList.add("hidden");
  codeScreen.classList.remove("hidden");
  document.getElementById("page-title").textContent = "Потвърди демо заявката";
  document.querySelector(".subtitle").textContent = "Последна стъпка — само демонстрация.";
  codeInputs[0].focus();
});

document.getElementById("back-button").addEventListener("click", () => {
  codeScreen.classList.add("hidden");
  detailsForm.classList.remove("hidden");
  document.getElementById("page-title").textContent = "Заяви своите Robux";
  document.querySelector(".subtitle").textContent = "Попълни полетата по-долу, за да продължиш.";
  codeError.classList.add("hidden");
});

codeInputs.forEach((input, index) => {
  input.addEventListener("input", () => {
    input.value = input.value.replace(/\s/g, "").slice(-1).toUpperCase();
    if (input.value && index < codeInputs.length - 1) codeInputs[index + 1].focus();
    codeError.classList.add("hidden");
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Backspace" && !input.value && index > 0) codeInputs[index - 1].focus();
    if (event.key === "Enter") document.getElementById("finish-button").click();
  });
  input.addEventListener("paste", (event) => {
    const pasted = (event.clipboardData || window.clipboardData).getData("text").replace(/\s/g, "").slice(0, 4).toUpperCase();
    if (!pasted) return;
    event.preventDefault();
    [...pasted].forEach((character, i) => { if (codeInputs[i]) codeInputs[i].value = character; });
    codeInputs[Math.min(pasted.length, 3)].focus();
  });
});

document.getElementById("finish-button").addEventListener("click", async () => {
  codeError.classList.add("hidden");
  const demoCode = codeInputs.map((input) => input.value).join("");
  if (demoCode.length !== 4) {
    codeError.textContent = "Въведи произволни 4 символа за демо.";
    codeError.classList.remove("hidden");
    codeInputs.find((input) => !input.value)?.focus();
    return;
  }

  const finishButton = document.getElementById("finish-button");
  finishButton.disabled = true;
  finishButton.textContent = "Изпращане…";
  try {
    // Only the chosen package is sent to the server. The code, phone, and nickname are never sent.
    const response = await fetch("/api/demo-submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ packageAmount: selectedPackage() })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Демо заявката не можа да бъде изпратена.");

    document.getElementById("order-id").textContent = result.orderId;
    document.getElementById("receipt-package").textContent = `${formatAmount(selectedPackage())} Robux`;
    document.getElementById("success-copy").textContent = result.notificationConfigured
      ? "Discord получи само демо ID, пакет и статус. Телефонът и въведеният код не са изпращани."
      : "Демо заявката е готова. Discord webhook не е конфигуриран, затова няма изпратено известие.";
    codeScreen.classList.add("hidden");
    successScreen.classList.remove("hidden");

    // Clear sensitive-looking demo fields after use, though they were never transmitted.
    document.getElementById("nickname").value = "";
    document.getElementById("phone").value = "";
    codeInputs.forEach((input) => input.value = "");
  } catch (error) {
    codeError.textContent = error.message;
    codeError.classList.remove("hidden");
  } finally {
    finishButton.disabled = false;
    finishButton.innerHTML = 'Завърши <span class="button-arrow">→</span>';
  }
});

function openHelp() {
  helpModal.classList.remove("hidden");
  document.getElementById("understood-button").focus();
}
function closeHelp() {
  helpModal.classList.add("hidden");
}
document.getElementById("sms-help-button").addEventListener("click", openHelp);
document.getElementById("close-modal").addEventListener("click", closeHelp);
document.getElementById("understood-button").addEventListener("click", closeHelp);
document.getElementById("modal-backdrop").addEventListener("click", closeHelp);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeHelp();
});

document.getElementById("restart-button").addEventListener("click", () => {
  successScreen.classList.add("hidden");
  detailsForm.classList.remove("hidden");
  codeScreen.classList.add("hidden");
  document.getElementById("page-title").textContent = "Заяви своите Robux";
  document.querySelector(".subtitle").textContent = "Попълни полетата по-долу, за да продължиш.";
  document.getElementById("nickname").value = "";
  document.getElementById("phone").value = "";
  codeInputs.forEach((input) => input.value = "");
  document.querySelector('input[name="package"][value="5000"]').checked = true;
  updatePackageState();
  detailsError.classList.add("hidden");
  codeError.classList.add("hidden");
});
